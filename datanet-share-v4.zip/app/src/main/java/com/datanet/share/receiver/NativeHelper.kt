package com.datanet.share.receiver

import android.util.Log
import java.io.FileDescriptor

/**
 * Native helper functions implemented in C for performance.
 *
 * The critical operations (checksum computation, TUN I/O) are 10x faster in C
 * than in Kotlin. This is the difference between 150 Mbps and 250+ Mbps.
 *
 * The native library is loaded lazily — if it fails to load (e.g., on an
 * unsupported architecture), the app falls back to the pure-Kotlin implementation.
 */
object NativeHelper {
    private const val TAG = "NativeHelper"

    @Volatile private var loaded = false
    @Volatile private var loadAttempted = false

    private fun loadIfNeeded() {
        if (loadAttempted) return
        loadAttempted = true
        try {
            System.loadLibrary("datanet_native")
            loaded = true
            Log.i(TAG, "Native library loaded successfully")
        } catch (e: Throwable) {
            Log.w(TAG, "Native library failed to load, using Kotlin fallback: ${e.message}")
            loaded = false
        }
    }

    fun isAvailable(): Boolean {
        loadIfNeeded()
        return loaded
    }

    // --- Checksum functions ---

    fun computeIpChecksum(pkt: ByteArray): Int? {
        if (!isAvailable()) return null
        return try {
            computeIpChecksumNative(pkt).toInt() and 0xFFFF
        } catch (e: Throwable) {
            Log.w(TAG, "native ip checksum failed: ${e.message}")
            null
        }
    }

    fun computeTcpChecksum(pkt: ByteArray, ipHdrLen: Int, tcpLen: Int): Int? {
        if (!isAvailable()) return null
        return try {
            computeTcpChecksumNative(pkt, ipHdrLen, tcpLen).toInt() and 0xFFFF
        } catch (e: Throwable) {
            Log.w(TAG, "native tcp checksum failed: ${e.message}")
            null
        }
    }

    fun computeUdpChecksum(pkt: ByteArray, ipHdrLen: Int, udpLen: Int): Int? {
        if (!isAvailable()) return null
        return try {
            computeUdpChecksumNative(pkt, ipHdrLen, udpLen).toInt() and 0xFFFF
        } catch (e: Throwable) {
            Log.w(TAG, "native udp checksum failed: ${e.message}")
            null
        }
    }

    // --- TUN I/O ---

    fun readTunBatch(fd: Int, buf: ByteArray, lengths: IntArray, maxPackets: Int): Int {
        if (!isAvailable()) return -1
        return try {
            readTunBatchNative(fd, buf, lengths, maxPackets)
        } catch (e: Throwable) {
            Log.w(TAG, "native readTunBatch failed: ${e.message}")
            -1
        }
    }

    fun writeTun(fd: Int, pkt: ByteArray): Int {
        if (!isAvailable()) return -1
        return try {
            writeTunNative(fd, pkt)
        } catch (e: Throwable) {
            Log.w(TAG, "native writeTun failed: ${e.message}")
            -1
        }
    }

    // --- Socket buffer sizing ---

    fun setSocketBuffers(fd: Int, size: Int): Boolean {
        if (!isAvailable()) return false
        return try {
            setSocketBuffersNative(fd, size)
        } catch (e: Throwable) {
            Log.w(TAG, "native setSocketBuffers failed: ${e.message}")
            false
        }
    }

    fun getFd(fileDescriptor: FileDescriptor): Int {
        if (!isAvailable()) return -1
        return try {
            getFdNative(fileDescriptor)
        } catch (e: Throwable) {
            Log.w(TAG, "native getFd failed: ${e.message}")
            -1
        }
    }

    // --- Native function declarations ---

    @JvmStatic private external fun computeIpChecksumNative(pkt: ByteArray): Short
    @JvmStatic private external fun computeTcpChecksumNative(pkt: ByteArray, ipHdrLen: Int, tcpLen: Int): Short
    @JvmStatic private external fun computeUdpChecksumNative(pkt: ByteArray, ipHdrLen: Int, udpLen: Int): Short
    @JvmStatic private external fun readTunBatchNative(fd: Int, buf: ByteArray, lengths: IntArray, maxPackets: Int): Int
    @JvmStatic private external fun writeTunNative(fd: Int, pkt: ByteArray): Int
    @JvmStatic private external fun setSocketBuffersNative(fd: Int, size: Int): Boolean
    @JvmStatic private external fun getFdNative(fileDescriptor: FileDescriptor): Int
}
