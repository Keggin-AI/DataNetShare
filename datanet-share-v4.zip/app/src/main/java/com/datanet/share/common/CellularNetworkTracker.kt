package com.datanet.share.common

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.util.Log
import java.net.Socket

object CellularNetworkTracker {
    private const val TAG = "CellularTracker"
    @Volatile private var cellularNetwork: Network? = null
    @Volatile private var cellularCaps: NetworkCapabilities? = null
    private var cm: ConnectivityManager? = null
    private var callback: ConnectivityManager.NetworkCallback? = null
    @Volatile private var started = false

    fun start(context: Context) {
        if (started) return
        started = true
        cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val mgr = cm ?: return
        try {
            val networks = mgr.allNetworks ?: emptyArray()
            for (network in networks) {
                val caps = mgr.getNetworkCapabilities(network) ?: continue
                if (caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) {
                    cellularNetwork = network; cellularCaps = caps; break
                }
            }
        } catch (_: Exception) {}
        val request = NetworkRequest.Builder().addTransportType(NetworkCapabilities.TRANSPORT_CELLULAR).addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET).build()
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) { cellularNetwork = network; try { cellularCaps = cm?.getNetworkCapabilities(network) } catch (_: Exception) {} }
            override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) { if (network == cellularNetwork) cellularCaps = caps }
            override fun onLost(network: Network) { if (network == cellularNetwork) { cellularNetwork = null; cellularCaps = null } }
        }
        callback = cb
        try { mgr.registerNetworkCallback(request, cb) } catch (_: Exception) {}
    }

    fun stop() {
        if (!started) return
        started = false
        try { callback?.let { cm?.unregisterNetworkCallback(it) } } catch (_: Exception) {}
        callback = null; cellularNetwork = null; cellularCaps = null
    }

    fun getCellularNetwork(): Network? = cellularNetwork
    fun createCellularSocket(): Socket? {
        val net = cellularNetwork ?: return null
        return try { net.socketFactory.createSocket() } catch (_: Exception) { null }
    }
    fun cellularAvailable(): Boolean = cellularNetwork != null
    fun describeNetwork(): String {
        val net = cellularNetwork ?: return "No cellular network"
        val caps = cellularCaps ?: return "Cellular network (no caps)"
        val downlink = caps.linkDownstreamBandwidthKbps
        val validated = caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
        return "Cellular: downlink=${downlink}kbps validated=$validated"
    }
}
