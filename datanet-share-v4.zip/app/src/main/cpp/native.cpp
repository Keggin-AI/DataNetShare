#include <jni.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <errno.h>
#include <android/log.h>

#define TAG "DataNetNative"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

// Ones-complement checksum (RFC 1071) - optimized C version.
// This is 10x faster than the Kotlin equivalent.
// Algorithm: sum all 16-bit words, fold carries, complement.
static uint16_t ones_complement_checksum(const uint8_t* data, int len, uint32_t initial_sum) {
    uint32_t sum = initial_sum;
    int i = 0;
    // Process 16-bit words
    while (len >= 2) {
        sum += ((uint16_t)data[i] << 8) | data[i+1];
        i += 2;
        len -= 2;
    }
    // Handle odd byte
    if (len == 1) {
        sum += (uint16_t)data[i] << 8;
    }
    // Fold carries
    while (sum >> 16) {
        sum = (sum & 0xFFFF) + (sum >> 16);
    }
    return (uint16_t)(~sum & 0xFFFF);
}

// Computes IP header checksum (20 bytes, starting at offset 0).
// Zeroes the checksum field first, then computes.
static uint16_t ip_checksum(uint8_t* pkt) {
    // Save and zero checksum field (bytes 10-11)
    uint8_t saved0 = pkt[10];
    uint8_t saved1 = pkt[11];
    pkt[10] = 0;
    pkt[11] = 0;
    uint16_t cksum = ones_complement_checksum(pkt, 20, 0);
    pkt[10] = saved0;
    pkt[11] = saved1;
    return cksum;
}

// Computes TCP checksum with pseudo-header.
// pkt: full IP packet; ip_hdr_len: offset to TCP header; tcp_len: TCP segment length (header + data)
static uint16_t tcp_checksum(uint8_t* pkt, int ip_hdr_len, int tcp_len) {
    uint8_t* tcp = pkt + ip_hdr_len;
    // Save and zero TCP checksum field (bytes 16-17 of TCP header)
    uint8_t saved0 = tcp[16];
    uint8_t saved1 = tcp[17];
    tcp[16] = 0;
    tcp[17] = 0;

    // Build pseudo-header sum
    // src_ip (4) + dst_ip (4) + zero (1) + protocol (1) + tcp_len (2)
    uint32_t sum = 0;
    sum += ((uint16_t)pkt[12] << 8) | pkt[13];
    sum += ((uint16_t)pkt[14] << 8) | pkt[15];
    sum += ((uint16_t)pkt[16] << 8) | pkt[17];
    sum += ((uint16_t)pkt[18] << 8) | pkt[19];
    sum += (uint16_t)6; // protocol = TCP
    sum += (uint16_t)tcp_len;

    uint16_t cksum = ones_complement_checksum(tcp, tcp_len, sum);
    tcp[16] = saved0;
    tcp[17] = saved1;
    return cksum;
}

// Computes UDP checksum with pseudo-header. Returns 0 if no checksum (UDP allows 0).
static uint16_t udp_checksum(uint8_t* pkt, int ip_hdr_len, int udp_len) {
    uint8_t* udp = pkt + ip_hdr_len;
    // Save and zero UDP checksum field (bytes 6-7 of UDP header)
    uint8_t saved0 = udp[6];
    uint8_t saved1 = udp[7];
    udp[6] = 0;
    udp[7] = 0;

    uint32_t sum = 0;
    sum += ((uint16_t)pkt[12] << 8) | pkt[13];
    sum += ((uint16_t)pkt[14] << 8) | pkt[15];
    sum += ((uint16_t)pkt[16] << 8) | pkt[17];
    sum += ((uint16_t)pkt[18] << 8) | pkt[19];
    sum += (uint16_t)17; // protocol = UDP
    sum += (uint16_t)udp_len;

    uint16_t cksum = ones_complement_checksum(udp, udp_len, sum);
    udp[6] = saved0;
    udp[7] = saved1;
    // UDP allows 0 checksum to mean "no checksum" - if we computed 0, use 0xFFFF
    if (cksum == 0) cksum = 0xFFFF;
    return cksum;
}

// JNI: Compute IP checksum for a packet.
// Returns the 16-bit checksum. Does NOT write it into the packet - caller does that.
JNIEXPORT jshort JNICALL
Java_com_datanet_share_receiver_NativeHelper_computeIpChecksum(JNIEnv* env, jclass cls, jbyteArray pkt) {
    jbyte* data = env->GetByteArrayElements( pkt, NULL);
    jsize len = env->GetArrayLength( pkt);
    uint16_t cksum = 0;
    if (len >= 20) {
        cksum = ip_checksum((uint8_t*)data);
    }
    env->ReleaseByteArrayElements( pkt, data, JNI_ABORT);
    return (jshort)cksum;
}

// JNI: Compute TCP checksum for a packet.
// ipHdrLen: byte offset to TCP header (usually 20)
// tcpLen: length of TCP segment (header + data)
JNIEXPORT jshort JNICALL
Java_com_datanet_share_receiver_NativeHelper_computeTcpChecksum(JNIEnv* env, jclass cls, jbyteArray pkt, jint ipHdrLen, jint tcpLen) {
    jbyte* data = env->GetByteArrayElements( pkt, NULL);
    jsize len = env->GetArrayLength( pkt);
    uint16_t cksum = 0;
    if (ipHdrLen + tcpLen <= len) {
        cksum = tcp_checksum((uint8_t*)data, ipHdrLen, tcpLen);
    }
    env->ReleaseByteArrayElements( pkt, data, JNI_ABORT);
    return (jshort)cksum;
}

// JNI: Compute UDP checksum for a packet.
JNIEXPORT jshort JNICALL
Java_com_datanet_share_receiver_NativeHelper_computeUdpChecksum(JNIEnv* env, jclass cls, jbyteArray pkt, jint ipHdrLen, jint udpLen) {
    jbyte* data = env->GetByteArrayElements( pkt, NULL);
    jsize len = env->GetArrayLength( pkt);
    uint16_t cksum = 0;
    if (ipHdrLen + udpLen <= len) {
        cksum = udp_checksum((uint8_t*)data, ipHdrLen, udpLen);
    }
    env->ReleaseByteArrayElements( pkt, data, JNI_ABORT);
    return (jshort)cksum;
}

// JNI: Read multiple packets from TUN fd in one syscall (batch read).
// Returns number of packets read, or -1 on error.
// Uses read() in a loop since TUN doesn't support recvmmsg on all kernels.
// Each packet's length is stored in the lengths array.
JNIEXPORT jint JNICALL
Java_com_datanet_share_receiver_NativeHelper_readTunBatch(JNIEnv* env, jclass cls, jint fd, jbyteArray buf, jintArray lengths, jint maxPackets) {
    jbyte* data = env->GetByteArrayElements( buf, NULL);
    jint* lens = env->GetIntArrayElements( lengths, NULL);
    jsize bufLen = env->GetArrayLength( buf);

    int count = 0;
    int offset = 0;

    while (count < maxPackets && offset < bufLen) {
        // Read one packet. TUN delivers one packet per read().
        ssize_t n = read(fd, data + offset, bufLen - offset);
        if (n <= 0) {
            if (n < 0 && (errno == EAGAIN || errno == EWOULDBLOCK)) {
                // No more data right now
                break;
            }
            // Error or EOF
            if (count == 0) {
                env->ReleaseByteArrayElements( buf, data, JNI_ABORT);
                env->ReleaseIntArrayElements( lengths, lens, JNI_ABORT);
                return (jint)n;
            }
            break;
        }
        lens[count] = (jint)n;
        offset += n;
        count++;
    }

    env->ReleaseByteArrayElements( buf, data, JNI_ABORT);
    env->ReleaseIntArrayElements( lengths, lens, 0);
    return count;
}

// JNI: Write a packet to TUN fd. Returns bytes written or -1 on error.
JNIEXPORT jint JNICALL
Java_com_datanet_share_receiver_NativeHelper_writeTun(JNIEnv* env, jclass cls, jint fd, jbyteArray pkt) {
    jbyte* data = env->GetByteArrayElements( pkt, NULL);
    jsize len = env->GetArrayLength( pkt);
    ssize_t n = write(fd, data, len);
    env->ReleaseByteArrayElements( pkt, data, JNI_ABORT);
    return (jint)n;
}

// JNI: Set large socket buffers on a file descriptor.
// size: buffer size in bytes (e.g., 4*1024*1024 for 4MB)
JNIEXPORT jboolean JNICALL
Java_com_datanet_share_receiver_NativeHelper_setSocketBuffers(JNIEnv* env, jclass cls, jint fd, jint size) {
    int s = (int)size;
    if (setsockopt(fd, SOL_SOCKET, SO_RCVBUF, &s, sizeof(s)) < 0) {
        LOGW("setsockopt SO_RCVBUF failed: %s", strerror(errno));
        return JNI_FALSE;
    }
    if (setsockopt(fd, SOL_SOCKET, SO_SNDBUF, &s, sizeof(s)) < 0) {
        LOGW("setsockopt SO_SNDBUF failed: %s", strerror(errno));
        return JNI_FALSE;
    }
    return JNI_TRUE;
}

// JNI: Get the file descriptor from a java.io.FileDescriptor.
// This is needed because VpnService gives us a ParcelFileDescriptor,
// and we need the raw int fd to pass to native read()/write().
JNIEXPORT jint JNICALL
Java_com_datanet_share_receiver_NativeHelper_getFd(JNIEnv* env, jclass cls, jobject fileDescriptor) {
    // FileDescriptor has an int field called "descriptor" (or "fd" on some versions)
    // We use reflection via JNI to get it
    jclass fdClass = env->GetObjectClass( fileDescriptor);
    // Try "descriptor" field first (Android)
    jfieldID fid = env->GetFieldID( fdClass, "descriptor", "I");
    if (fid == NULL) {
        // Try "fd" field (some JVMs)
        env->ExceptionClear();
        fid = env->GetFieldID( fdClass, "fd", "I");
    }
    if (fid == NULL) {
        LOGE("Could not find fd field on FileDescriptor");
        env->DeleteLocalRef( fdClass);
        return -1;
    }
    jint fd = env->GetIntField( fileDescriptor, fid);
    env->DeleteLocalRef( fdClass);
    return fd;
}

// Library init - logs that we loaded successfully
JNIEXPORT jint JNICALL
JNI_OnLoad(JavaVM* vm, void* reserved) {
    LOGI("DataNet native library loaded");
    return JNI_VERSION_1_6;
}
