# Add project specific ProGuard rules here.
-keep class com.datanet.share.** { *; }
